export default function Home() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial, sans-serif" }}>
      <h1>Welcome to FacilityBooking.ai</h1>
      <p>This is your new Next.js deployment.</p>
    </div>
  );
}
